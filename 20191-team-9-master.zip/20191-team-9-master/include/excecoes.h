#ifndef EXCECOES_H
#define EXCECOES_H

#include <stdexcept>

using namespace std;

class ArgumentoInvalido : public exception{};

#endif
