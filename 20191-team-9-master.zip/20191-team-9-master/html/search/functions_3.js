var searchData=
[
  ['ecommerce',['Ecommerce',['../class_ecommerce.html#a3a1e67dca201bf8b5729799c521e67da',1,'Ecommerce']]],
  ['excluiusuario',['excluiUsuario',['../class_administrador.html#a066e1af058776437c43a98dabb44f02b',1,'Administrador']]],
  ['exibirperfil',['exibirPerfil',['../class_comprador.html#a35d18c3bcfff0adfe8dd3b75f46f8bd8',1,'Comprador']]]
];
