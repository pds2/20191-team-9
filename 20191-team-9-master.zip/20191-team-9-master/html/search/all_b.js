var searchData=
[
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['removeitem',['removeItem',['../class_administrador.html#ac3032625947549cda5dd58fa7a8a1544',1,'Administrador']]],
  ['retirarcarrinho',['retirarCarrinho',['../class_comprador.html#a8a5fc62485a3a9b37340609715e73feb',1,'Comprador']]],
  ['retornanumcomentarios',['retornaNumComentarios',['../class_produto.html#aad630dde537191383c0140c91f74f9ed',1,'Produto']]]
];
