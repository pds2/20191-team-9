var searchData=
[
  ['blusasemoletom',['BlusasEMoletom',['../class_blusas_e_moletom.html#aedc119affff5e7685176d0e4bdf8170e',1,'BlusasEMoletom']]],
  ['buscaindiceacessorio',['buscaIndiceAcessorio',['../class_ecommerce.html#ab21ff2a4e6ddd10b01b6cd8e7b8823f8',1,'Ecommerce']]],
  ['buscaindiceblusasemoletom',['buscaIndiceBlusasEMoletom',['../class_ecommerce.html#a99b2d10659b9fe41cc9f5a44cf8a2977',1,'Ecommerce']]],
  ['buscaindicecaneca',['buscaIndiceCaneca',['../class_ecommerce.html#a7f148dfc9339dfd26b021185e431cd1f',1,'Ecommerce']]],
  ['buscaindiceprodutos',['buscaIndiceProdutos',['../class_ecommerce.html#af2d514aa14dbca0c0e06337efa7f668a',1,'Ecommerce']]]
];
