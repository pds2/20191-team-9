var searchData=
[
  ['tamanhoarquivo',['tamanhoArquivo',['../class_ecommerce.html#acd1391717ff24f1186ffa2921db5adfe',1,'Ecommerce']]]
];
