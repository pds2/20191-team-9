var searchData=
[
  ['fazercompras',['fazerCompras',['../class_comprador.html#a93794d8122ae9f09f192af5d0c027527',1,'Comprador']]]
];
