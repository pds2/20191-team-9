var searchData=
[
  ['setcomentario',['setComentario',['../class_produto.html#a36bac4cf6ea3bab2f16ef4e9ae3c8f77',1,'Produto']]],
  ['setdinheiro',['setDinheiro',['../class_comprador.html#a4f22858b4fdd931a81dd8cfcd4783bde',1,'Comprador']]]
];
