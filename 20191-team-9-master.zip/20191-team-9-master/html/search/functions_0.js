var searchData=
[
  ['acessorio',['Acessorio',['../class_acessorio.html#af1afa7c30c469f4ab78ac1bea3ee6334',1,'Acessorio']]],
  ['addcarrinho',['addCarrinho',['../class_ecommerce.html#af2624f7386194d09f7766756f3c08d73',1,'Ecommerce']]],
  ['adicionacomentario',['adicionaComentario',['../class_ecommerce.html#a02ae0b7c3a6f79748410137ba513fee9',1,'Ecommerce']]],
  ['adicionadinheiro',['adicionaDinheiro',['../class_comprador.html#ab996419e954d24ac9c97e646e81b0c9c',1,'Comprador']]],
  ['adicionarcarrinho',['adicionarCarrinho',['../class_comprador.html#a321ef648a886ea8c567c5030e6ea1e65',1,'Comprador']]],
  ['adicionarcomentario',['adicionarComentario',['../class_comprador.html#aef06de4d0e7dfaeb5ad5411e895e31b3',1,'Comprador']]],
  ['administrador',['Administrador',['../class_administrador.html#a493c6aa5f70e459339fd7f05c12237b0',1,'Administrador']]],
  ['aprovapedido',['aprovaPedido',['../class_administrador.html#a05604fe263be531162e5e98f57d5d5c2',1,'Administrador']]],
  ['avaliaritem',['avaliarItem',['../class_comprador.html#a10b29882e2737563350cdf6f157d82b4',1,'Comprador']]],
  ['avaliarproduto',['avaliarProduto',['../class_produto.html#ab09e6f36f81eb4545ce91dfc14f017b7',1,'Produto']]]
];
