#include <iostream>

#include "ecommerce.h"

int main(int argc, char const *argv[]) {

  Ecommerce ecom;
  ecom.imprimirCompradores();
  ecom.listaUsuarioArquivo();

return 0;
}
